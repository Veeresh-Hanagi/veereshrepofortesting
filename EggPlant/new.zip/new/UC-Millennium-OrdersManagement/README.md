# NewRepo-Template

Repository for [component/application] Eggplant automation.

* [Dependencies](#dependencies)
* [Credentials](#credentials)
* [Suites](#suites)
* [Continous Integration](#continuous-integration)

## Dependencies
* This project depends on: 
	* [ipdev-desktop-shared]
	* [ipdev-utilities-shared]
	* [ipdev-citrix-shared]
    * [ipdev-millennium-shared]
* Install dependencies using npm.  Refer to [Eggplant Dependencies].
    *  Refer to [package.json] for dependencies
* Citrix needs to be installed and trusted on the the [SUT] (System Under Test) if using Citrix platform.
* If not using npm you can use [CloneDependencies] batch file to clone all needed dependency repositories, then manually add as helper suites to SUITEINFO

## Credentials

Test Credentials are stored within the Cerner Vault safe [Eggplant-Template]. 

## Suites

* [Template-Shared.suite]
* [Template-Tests.suite]

### Template-Shared.suite

This suite contains shared scripts.

#### Shared Scripts

* [TMP/AmazonShopping] - Shared handlers for on shopping on Amazon.com.

### Template-Tests.suite
This suite contains Eggplant test scripts for verification using a corresponding [SUT] (System Under Test)

#### Test Scripts

* [TMP-VR-AmazonCart] -- Visit Amazon, add item to cart and checkout
* [TMP-VR-MillenniumIntegration-Test] - Open Powerchart app, search for patient and navigate menu

#### SUT
For assistance on creating a local SUT refer to [EggPlant - Connection to SUTs].

## Continuous Integration

SCA Build jobs can be found [here][jenkins-jobs].
Jenkins builds this project according to the [Jenkinsfile](Jenkinsfile).  

For RQM configuration refer to the [Eggplant+Tool+Integration+Guidelines] wiki


[Default Suite Directory]: http://docs.testplant.com/ePF/using/epf-general-preferences.htm
[Helper Suites]: http://docs.testplant.com/ePF/using/epf-settings-tab.htm
[Template-Tests.suite]: #template-testssuite
[Template-Shared.suite]: #template-sharedsuite
[Shared Scripts]: #shared-scripts
[Test Scripts]: #test-scripts
[SUT]: #sut
[Eggplant Dependencies]: https://wiki.cerner.com/display/Ion/Eggplant+configuration+for+dependencies
[jenkins-jobs]: https://https://jenkins.cerner.com/eggplantstaticcodeanalysis/job/Eggplant/job/NewRepo-Template
[EggPlant - Connection to SUTs]: https://wiki.cerner.com/display/IPDevConDoc/Eggplant+-+Connecting+to+SUTs
[Eggplant+Tool+Integration+Guidelines]: https://wiki.cerner.com/display/public/IPDevConDoc/Eggplant+Tool+Integration+Guidelines#EggplantToolIntegrationGuidelines-EggplantandRQM
[JIRA Project]: https://jira2.cerner.com/projects/XYZ
[Eggplant-Template]: https://vault.cerner.com/safe?companyID=13224
[TMP/AmazonShopping]: ./Template-Shared.suite/Scripts/TMP/AmazonShopping.script
[TMP-VR-MillenniumIntegration-Test]: ./Template-Tests.suite/Scripts/TMP-VR-MillenniumIntegration-Test.script
[TMP-VR-AmazonCart]: ./Template-Tests.suite/Scripts/TMP-VR-AmazonCart.script
[package.json]: ./package.json
[ipdev-desktop-shared]: https://github.cerner.com/EggPlant/IPDEV-Desktop-Shared/tree/master/Desktop-Shared.suite
[ipdev-utilities-shared]: https://github.cerner.com/EggPlant/IPDEV-Utilities-Shared/tree/master/Utilities-Shared.suite
[ipdev-citrix-shared]: https://github.cerner.com/EggPlant/IPDEV-Citrix-Shared/tree/master/Citrix-Shared.suite
[ipdev-millennium-shared]: https://github.cerner.com/EggPlant/IPDEV-Millennium-Shared/tree/master/Millennium-Shared.suite
[CloneDependencies]: ./CloneDependencies.bat
